
  IF your client does not support texture ".link" files,
  you have to copy all textures from /romerobase/ to /romerobase_x/
  or you will see lower quality textures.
